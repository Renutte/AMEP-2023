import javax.swing.*;

public class MainWindow extends JFrame {
    private JPanel panel1;
    private JLabel title;
    public MainWindow(){
        setContentPane(panel1);
    }
}
